import os

from google.appengine.ext.webapp import template
from google.appengine.ext import webapp
from google.appengine.ext.webapp.util import run_wsgi_app
from google.appengine.ext import db
from bookmodels  import *

class MainPage(webapp.RequestHandler):
     def get(self):
         publisher_query = Publisher.all()
         publishers = publisher_query.fetch(10)
         author_query = Author.all()
         authors = author_query.fetch(20)
         book_query = Book.all()
         books = book_query.fetch(20)

         template_values = {
            'publishers': publishers,
            'authors': authors,
            'books': books,
         }
         path = os.path.join(os.path.dirname(__file__), 'index.html')
         
         self.response.out.write(template.render(path, template_values))


application = webapp.WSGIApplication([('/',MainPage)],debug=True)

def main():
    bkdb_create()
    run_wsgi_app(application)



if __name__ == "__main__":
    main()
