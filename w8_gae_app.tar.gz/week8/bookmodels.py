from google.appengine.ext import db
import datetime

class Publisher(db.Model):
    name = db.StringProperty(multiline=False)

class Book(db.Model):
    publisher = db.ReferenceProperty(Publisher, collection_name = 'books')

    title = db.StringProperty(multiline=False)
    edition = db.StringProperty(multiline=False)
    isbn10 = db.StringProperty(multiline=False)
    pub_date = db.DateProperty(auto_now_add=False)

    def get_info(self):
        '''
        returns book info in string
        '''
        return self.title+', '+self.edition+' edition, '+str(self.pub_date)\
                +', '+self.publisher.name+', ISBN:'+self.isbn10

    def get_authors(self):
         '''
         returns a list of authors by the author
         '''
         return Author.gql("WHERE books = :1", self.key())

class Author(db.Model):
    ### written books by the author ###
    books = db.ListProperty(db.Key)

    ### author's name ###
    last_n = db.StringProperty(multiline=False)
    first_n = db.StringProperty(multiline=False)
    middle_n = db.StringProperty(multiline=False)

    def get_fullname(self):
        """
        returns author's full name in string
        """
        if self.middle_n == '':
            return self.first_n+' '+self.last_n
        else:
            return self.first_n+' '+self.middle_n+' '+self.last_n


def bkdb_create():
    bookdb = Book()
#    authordb = Author()

### Create Publisher table ###
    sams = Publisher(name='Sams')
    sams.put()
    oreilly = Publisher(name='O\'Reilly Media')
    oreilly.put()
    apress = Publisher(name='Apress')
    apress.put()
    pragmatic = Publisher(name='Pragmatic Bookshelf')
    pragmatic.put()
    addisonwesley = Publisher(name='Addison-Wesley Professional')
    addisonwesley.put()
    coursetech = Publisher(name='Course Technology PTR')
    coursetech.put()
    manning = Publisher(name='Manning Publications')
    manning.put()

### Create Book table ###

    py_web_prog = Book(title='Python Web Programming',
                  edition='first',
                  publisher=sams,
                  isbn10='0735710902',
                  pub_date=datetime.date(2002, 1 ,18))
    py_web_prog.put()
    py_cook = Book(title='Python Cookbook',
                  edition='second',
                  publisher=oreilly,
                  isbn10='0596007973',
                  pub_date=datetime.date(2005, 3, 18))
    py_cook.put()
    py_in_a_nut = Book(title='Python in a Nutshell',
                  edition='second',
                  publisher=oreilly,
                  isbn10='0596100469',
                  pub_date=datetime.date(2006, 7, 14))
    py_in_a_nut.put()
    begin_py = Book(title='Beginning Python: From Novice to Professional ',
                  edition='second',
                  publisher=apress,
                  isbn10='1590599829',
                  pub_date=datetime.date(2008, 9, 19))
    begin_py.put()
    practical_prog = Book(title='Practical Programming: An Introduction to Computer Science Using Python',
                  edition='first',
                  publisher=pragmatic,
                  isbn10='1934356271',
                  pub_date=datetime.date(2009, 3, 28))
    practical_prog.put()
    py_essential = Book(title='Python Essential Reference',
                  edition='fourth',
                  publisher=addisonwesley,
                  isbn10='0672329786',
                  pub_date=datetime.date(2009, 7, 19))
    py_essential.put()
    learning_py = Book(title='Learning Python: Powerful Object-Oriented Programming',
                  edition='fourth',
                  publisher=oreilly,
                  isbn10='0596158068',
                  pub_date=datetime.date(2009, 10, 2))
    learning_py.put()
    prog_in_py3 = Book(title='Programming in Python 3: A Complete Introduction to the Python Language',
                  edition='second',
                  publisher=addisonwesley,
                  isbn10='0321680561',
                  pub_date=datetime.date(2009, 11, 22))
    prog_in_py3.put()
    py_prog_abs = Book(title='Python Programming for the Absolute Beginner',
                  edition='third',
                  publisher=coursetech,
                  isbn10='1435455002',
                  pub_date=datetime.date(2010, 1, 1))
    py_prog_abs.put()
    quick_py = Book(title='The Quick Python Book',
                  edition='second',
                  publisher=manning,
                  isbn10='193518220X',
                  pub_date=datetime.date(2010, 1, 15))
    quick_py.put()
    pro_py = Book(title='Pro Python ',
                  edition='first',
                  publisher=apress,
                  isbn10='1430227575',
                  pub_date=datetime.date(2010, 6, 15))
    pro_py.put()
    py_algo = Book(title='Python Algorithms: Mastering Basic Algorithms in the Python Language ',
                  edition='first',
                  publisher=apress,
                  isbn10='1430232374',
                  pub_date=datetime.date(2010, 11, 24))
    py_algo.put()
    head_first_py = Book(title='Head First Python',
                  edition='first',
                  publisher=oreilly,
                  isbn10='1449382673',
                  pub_date=datetime.date(2010, 11, 30))
    head_first_py.put()
    program_py = Book(title='Programming Python',
                  edition='fourth',
                  publisher=oreilly,
                  isbn10='0596158106',
                  pub_date=datetime.date(2010, 12, 31))
    program_py.put()

### Create Author table ###
    holden_s = Author(last_n='Holden', first_n='Steve', middle_n='')
    if py_web_prog.key() not in holden_s.books:
        holden_s.books.append(py_web_prog.key())
    holden_s.put()

    martelli_a = Author(last_n='Martelli', first_n='Alex', middle_n='')
    if py_cook.key() not in martelli_a.books:
        martelli_a.books.append(py_cook.key())
    if py_in_a_nut.key() not in martelli_a.books:
        martelli_a.books.append(py_in_a_nut.key())
    martelli_a.put()

    ravenscroft_a = Author(last_n='Ravenscroft', first_n='Anna', middle_n='')
    if py_cook.key() not in ravenscroft_a.books:
        ravenscroft_a.books.append(py_cook.key())
    ravenscroft_a.put()

    ascher_d = Author(last_n='Ascher', first_n='David', middle_n='')
    if py_in_a_nut.key() not in ascher_d.books:
        ascher_d.books.append(py_in_a_nut.key())
    ascher_d.put()

    hetland_m = Author(last_n='Hetland', first_n='Magnus', middle_n='Lie')
    if begin_py.key() not in hetland_m.books:
        hetland_m.books.append(begin_py.key())
    if py_algo.key() not in hetland_m.books:
        hetland_m.books.append(py_algo.key())
    hetland_m.put()

    campbell_j = Author(last_n='Campbell', first_n='Jennifer', middle_n='')
    if practical_prog.key() not in campbell_j.books:
        campbell_j.books.append(practical_prog.key())
    campbell_j.put()

    gries_p = Author(last_n='Gries', first_n='Paul', middle_n='')
    if practical_prog.key() not in gries_p.books:
        gries_p.books.append(practical_prog.key())
    gries_p.put()

    montojo_j = Author(last_n='Montojo', first_n='Jason', middle_n='')
    if practical_prog.key() not in montojo_j.books:
        montojo_j.books.append(practical_prog.key())
    montojo_j.put()

    wilson_g = Author(last_n='Wilson', first_n='Greg', middle_n='')
    if practical_prog.key() not in wilson_g.books:
        wilson_g.books.append(practical_prog.key())
    wilson_g.put()

    beazley_d = Author(last_n='Beazley', first_n='David', middle_n='M.')
    if py_essential.key() not in beazley_d.books:
        beazley_d.books.append(py_essential.key())
    beazley_d.put()

    lutz_m = Author(last_n='Lutz', first_n='Mark', middle_n='')
    if learning_py.key() not in lutz_m.books:
        lutz_m.books.append(learning_py.key())
    if program_py.key() not in lutz_m.books:
        lutz_m.books.append(program_py.key())
    lutz_m.put()

    summerfield_m = Author(last_n='Summerfield', first_n='Mark', middle_n='')
    if prog_in_py3 not in summerfield_m.books:
        summerfield_m.books.append(prog_in_py3.key())
    summerfield_m.put()

    dawson_m = Author(last_n='Dawson', first_n='Michael', middle_n='')
    if py_prog_abs.key() not in dawson_m.books:
        dawson_m.books.append(py_prog_abs.key())
    dawson_m.put()

    ceder_v = Author(last_n='Ceder', first_n='Vern', middle_n='')
    if quick_py.key() not in ceder_v.books:
        ceder_v.books.append(quick_py.key())
    ceder_v.put()

    alchin_m = Author(last_n='Alchin', first_n='Marty', middle_n='')
    if pro_py.key() not in alchin_m.books:
        alchin_m.books.append(pro_py.key())
    alchin_m.put()

    barry_p = Author(last_n='Barry', first_n='Paul', middle_n='');
    if head_first_py.key() not in barry_p.books:
        barry_p.books.append(head_first_py.key())
    barry_p.put()
