from booklist.models import Book, Author, Publisher
from django.contrib import admin

admin.site.register(Book)
admin.site.register(Author)
admin.site.register(Publisher)
