from django.conf.urls.defaults import *

from django.contrib import admin

admin.autodiscover()

urlpatterns = patterns('',
    # Example:
    # (r'^w7assign/', include('w7assign.foo.urls')),

    # Uncomment the admin/doc line below to enable admin documentation:
    # (r'^admin/doc/', include('django.contrib.admindocs.urls')),
    (r'^booklist/$', 'booklist.views.index'),
    (r'^booklist/book(?P<book_id>\d+)/$', 'booklist.views.detail'),
    (r'^booklist/author(?P<author_id>\d+)/$', 'booklist.views.author'),
    (r'^booklist/publisher(?P<publisher_id>\d+)/$', 'booklist.views.publisher'),
    (r'^admin/', include(admin.site.urls)),
)
