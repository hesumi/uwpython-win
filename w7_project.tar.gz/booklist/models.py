from django.db import models

class Book(models.Model):
	'''
	each row represetns a book written by author(s) and published by a publisher
	'''
	title = models.CharField(max_length=200)		# Book title
	edition = models.CharField(max_length=16)		# Edition
	isbn10 = models.CharField(max_length=10)		# ISBN-10
	pub_date = models.DateField('date published')	# Publishing date
	publisher = models.ForeignKey('Publisher')		# Publisher (Foreign Key)

	def __unicode__(self):
		return self.title+', '+self.edition

	### This mothod is not used anywhere ###
	def get_authors(self):
		a_lst = []
		for auth in self.author_set.all():
			if auth.middle_n == '':
				a_lst.append((auth.id, auth.first_n+' '+auth.last_n))
			else:
				a_lst.append((auth.id, auth.first_n+' '+auth.middle_n+' '+auth.last_n))
		return a_lst

class Author(models.Model):
	'''
	each row represents an author of book(s)
	'''
	last_n = models.CharField(max_length=32)		# Last name
	first_n = models.CharField(max_length=32)		# First name
	middle_n = models.CharField(max_length=32, null=True, blank=True)		# Middle name
	book = models.ManyToManyField('Book')			# Many-to-many relation w/ Book

	def __unicode__(self):
		return self.last_n+', '+self.first_n

	def get_fullname(self):
		'''
		returns author's full name in string
		'''
		if self.middle_n == '':
			return self.first_n+' '+self.last_n
		else:
			return self.first_n+' '+self.middle_n+' '+self.last_n

class Publisher(models.Model):
	'''
	each row represents a publisher of book(s)
	'''
	name = models.CharField(max_length=64)			# Name of Publisher

	def __unicode__(self):
		return self.name
