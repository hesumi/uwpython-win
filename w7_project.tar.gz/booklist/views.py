from django.shortcuts import render_to_response, get_object_or_404
from booklist.models import Book, Author, Publisher

def index(request):
	'''
	construct the main book list page
	'''
	book_list = Book.objects.all().order_by('title')
#	return render_to_response('booklist/index.html', {'book_list': book_list})
	return render_to_response('booklist/index.html', {'book_list': book_list})

def detail(request, book_id):
	'''
	construct each book detail page
	'''
	b = get_object_or_404(Book, pk=book_id)
	### pass a book object ###
	return render_to_response('booklist/detail.html', {'book': b})

def author(request, author_id):
	'''
	construct each author page
	'''
	a = get_object_or_404(Author, pk=author_id)
	b = a.book.all()
	### pass an author object and a list of books written by the author ###
	return render_to_response('booklist/author.html', {'author': a, 'books': b})

def publisher(request, publisher_id):
	'''
	construct each publisher page
	'''
	p = get_object_or_404(Publisher, pk=publisher_id)
	b = p.book_set.all()
	### pass a publisher object and a list of books published by the publisher ###
	return render_to_response('booklist/publisher.html', {'publisher': p, 'books': b})
